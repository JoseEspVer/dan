package org.e2e.labe2e01.ride.domain;

public enum Status {
    REQUESTED, ACCEPTED, IN_PROGRESS, COMPLETED, CANCELLED
}
