package org.e2e.labe2e01.vehicle.domain;

import org.springframework.stereotype.Service;

@Service
public class VehicleService {
    // Dependency injection and methods
}
