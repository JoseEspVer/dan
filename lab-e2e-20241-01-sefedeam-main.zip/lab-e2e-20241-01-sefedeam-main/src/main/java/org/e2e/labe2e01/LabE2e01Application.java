package org.e2e.labe2e01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabE2e01Application {

	public static void main(String[] args) {
		SpringApplication.run(LabE2e01Application.class, args);
	}

}
