package org.e2e.labe2e01.driver.domain;

public enum Category {
    X, XL, BLACK
}
