package org.e2e.labe2e01.user.domain;

public enum Role {
    ADMIN,PASSENGER, DRIVER
}
