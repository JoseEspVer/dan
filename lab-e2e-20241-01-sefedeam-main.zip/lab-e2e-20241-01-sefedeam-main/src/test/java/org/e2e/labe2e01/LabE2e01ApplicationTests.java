package org.e2e.labe2e01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabE2e01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
